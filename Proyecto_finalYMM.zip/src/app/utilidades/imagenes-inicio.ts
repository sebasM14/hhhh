export const  ARREGLO_IMAGENES: Array<any> =[ 
    {codigo:1, ruta:'../../../../assets/img/banne.jpg' ,  titulo: '', descripcion: ''},
    {codigo:2,ruta:'../../../../assets/img/bannerThree.png' , titulo: 'Nrj', descripcion: 'Lorem ashdhsdhsshdshdshshds'},
    {codigo:3, ruta:'../../../../assets/img/bannerTwo.png', titulo: 'Ney siendo el mejor de todos', descripcion: 'Lorem ashdhsdhsshdshdshshds'}
  
     
      //... más imágenes
    ];
  
  