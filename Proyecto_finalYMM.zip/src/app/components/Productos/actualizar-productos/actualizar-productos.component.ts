import { Component } from '@angular/core';

@Component({
  selector: 'app-actualizar-productos',
  templateUrl: './actualizar-productos.component.html',
  styleUrl: './actualizar-productos.component.css'
})
export class ActualizarProductosComponent {

}
